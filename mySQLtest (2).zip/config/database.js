module.exports = {
  host: "localhost",
  user: "root",
  password: "ekdnsel",
  database: "dawoon_disinfect",
};
